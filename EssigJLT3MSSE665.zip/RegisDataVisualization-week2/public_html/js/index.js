/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var kpi1Data;
var kpi2Data;
var kpi3Data;
var kpi4Data;

function clearKPIs(){}
function flotr2(){}
function chartjs(){}
function chartlist(){}
function google(){}
function d3(){}
function leaflet(){}

window.onload = function () { 
    
    kpi1Data = [[[1, 2.21], [2, 2.75], [3, 5.6], [4, 4.9]]];
    kpi2Data = [[[1, 1.3], [2, 1.4], [3, 1.4], [4, 1.3]]];
    kpi3Data = [[[1, 0.8], [2, 1.35], [3, 4.2], [4, 3.6]]];
    kpi4Data = [[[1,75], [2,83], [3, 150], [4, 130]]]
};